<?php
// This file was auto-generated from sdk-root/src/data/email/2010-12-01/paginators-1.json
return [ 'pagination' => [ 'ListIdentities' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxItems', 'result_key' => 'Identities', ], 'ListVerifiedEmailAddresses' => [ 'result_key' => 'VerifiedEmailAddresses', ], ],];
